
# Natural Language UI Starter

This is a stripped-down UI-only starter project from the original `natural-language-postgres` repo. It's built with **Next.js**, **Tailwind CSS**, and **TypeScript** to help you quickly start a natural language-based app interface.

---

## 🚀 How to Run in VS Code

### 1. Prerequisites
- **Node.js** (v18 or later): [Download Node.js](https://nodejs.org/)
- **VS Code** with the extensions:
  - ESLint (optional)
  - Tailwind CSS IntelliSense (optional)

---

### 2. Setup

#### 🔹 Step 1: Open Project
- Extract this zip and open the folder in **VS Code**

#### 🔹 Step 2: Install Dependencies
```bash
npm install
```

#### 🔹 Step 3: Run the Dev Server
```bash
npm run dev
```

Then open: [http://localhost:3000](http://localhost:3000)

---

## 📁 Project Structure

- `app/` – Main UI logic (`layout.tsx`, `page.tsx`, `globals.css`)
- `components/` – UI components (e.g., `DeployButton`)
- `tailwind.config.js` – Tailwind CSS setup
- `postcss.config.js` – PostCSS setup for Tailwind
- `tsconfig.json` – TypeScript project settings

---

## ✅ Notes

- Tailwind is preconfigured and ready to use.
- TypeScript is optional, but already set up.
- You can plug in your own logic or API into the UI flow easily.

---

## 🛠 Customize

To add your backend or API:
- Connect your logic via `/app/actions.ts` or add an `/api` route.
- Adjust the layout and styling as needed using Tailwind.

---

Happy coding!
